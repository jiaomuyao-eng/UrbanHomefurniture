# UrbanHome

Minecraft Java 1.21.1 + Fabric 0.19.5 furniture mod scaffold.

## Build
Use Java 21 and run:

    ./gradlew build

The compiled JAR will be in `build/libs/`.

## Current content
100 registered furniture blocks with block/item models, blockstates, textures, language entries and loot tables.

This first build uses lightweight placeholder 16x16 textures and simple low-poly block models so the project remains small and easy to replace with final artwork later.
