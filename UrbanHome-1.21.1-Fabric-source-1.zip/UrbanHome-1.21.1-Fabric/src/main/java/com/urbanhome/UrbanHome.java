package com.urbanhome;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UrbanHome implements ModInitializer {
    public static final String MOD_ID = "urbanhome";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModBlocks.register();
        ModItemGroup.register();
        LOGGER.info("UrbanHome loaded: 100 furniture blocks.");
    }
}
