package com.urbanhome;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class ModItemGroup {
    public static final ItemGroup URBANHOME = FabricItemGroup.builder()
        .displayName(Text.translatable("itemGroup.urbanhome"))
        .icon(() -> new ItemStack(ModBlocks.LUXURY_FIREPLACE))
        .entries((displayContext, entries) -> {
            entries.add(ModBlocks.OFFICE_DESK);
            entries.add(ModBlocks.OFFICE_CHAIR);
            entries.add(ModBlocks.PRINTER);
            entries.add(ModBlocks.FILING_CABINET);
            entries.add(ModBlocks.BOOKSHELF);
            entries.add(ModBlocks.WALL_SCREEN);
            entries.add(ModBlocks.MEETING_TABLE);
            entries.add(ModBlocks.CONFERENCE_CHAIR);
            entries.add(ModBlocks.LAPTOP);
            entries.add(ModBlocks.SERVER_RACK);
            entries.add(ModBlocks.TROPHY_CABINET);
            entries.add(ModBlocks.AQUARIUM);
            entries.add(ModBlocks.PIANO);
            entries.add(ModBlocks.PROJECTOR);
            entries.add(ModBlocks.PROJECTOR_SCREEN);
            entries.add(ModBlocks.SCULPTURE);
            entries.add(ModBlocks.VASE);
            entries.add(ModBlocks.LARGE_PLANT);
            entries.add(ModBlocks.ARTWORK_FRAME);
            entries.add(ModBlocks.LUXURY_MIRROR);
            entries.add(ModBlocks.GRAND_CHANDELIER);
            entries.add(ModBlocks.OUTDOOR_SOFA);
            entries.add(ModBlocks.GARDEN_CHAIR);
            entries.add(ModBlocks.PATIO_TABLE);
            entries.add(ModBlocks.UMBRELLA);
            entries.add(ModBlocks.BBQ_GRILL);
            entries.add(ModBlocks.POOL_CHAIR);
            entries.add(ModBlocks.GARDEN_LAMP);
            entries.add(ModBlocks.FLOWER_POT);
            entries.add(ModBlocks.FIRE_PIT);
            entries.add(ModBlocks.MODERN_GATE);
            entries.add(ModBlocks.INDOOR_FOUNTAIN);
            entries.add(ModBlocks.MODERN_STAIR_DECOR);
            entries.add(ModBlocks.GLASS_WALL);
            entries.add(ModBlocks.WINE_RACK);
            entries.add(ModBlocks.LUXURY_BENCH);
            entries.add(ModBlocks.CORNER_SOFA);
            entries.add(ModBlocks.DECORATIVE_SHELF);
            entries.add(ModBlocks.TABLE_DECOR);
            entries.add(ModBlocks.MEDIA_CONSOLE);
            entries.add(ModBlocks.LOUNGE_CHAIR);
            entries.add(ModBlocks.BALCONY_PLANT);
            entries.add(ModBlocks.GUEST_BED);
            entries.add(ModBlocks.COAT_RACK);
            entries.add(ModBlocks.LAUNDRY_BASKET);
            entries.add(ModBlocks.BATHROOM_VANITY);
            entries.add(ModBlocks.LUXURY_BATHTUB);
            entries.add(ModBlocks.SMART_TOILET);
            entries.add(ModBlocks.RAIN_SHOWER);
            entries.add(ModBlocks.KITCHEN_ISLAND);
            entries.add(ModBlocks.REFRIGERATOR);
            entries.add(ModBlocks.OVEN_TOWER);
            entries.add(ModBlocks.COFFEE_MACHINE);
            entries.add(ModBlocks.KITCHEN_SHELF);
            entries.add(ModBlocks.SMART_TV);
            entries.add(ModBlocks.SPEAKER_SYSTEM);
            entries.add(ModBlocks.FLOOR_LAMP);
            entries.add(ModBlocks.CEILING_FAN);
            entries.add(ModBlocks.CURTAIN);
            entries.add(ModBlocks.DINING_TABLE);
            entries.add(ModBlocks.DINING_CHAIR);
            entries.add(ModBlocks.BAR_STOOL);
            entries.add(ModBlocks.SIDEBOARD);
            entries.add(ModBlocks.COFFEE_TABLE);
            entries.add(ModBlocks.END_TABLE);
            entries.add(ModBlocks.SECTIONAL_SOFA);
            entries.add(ModBlocks.RECLINER);
            entries.add(ModBlocks.TV_STAND);
            entries.add(ModBlocks.BED_FRAME);
            entries.add(ModBlocks.KING_BED);
            entries.add(ModBlocks.WARDROBE);
            entries.add(ModBlocks.DRESSER);
            entries.add(ModBlocks.NIGHTSTAND);
            entries.add(ModBlocks.DESK_LAMP);
            entries.add(ModBlocks.READING_LAMP);
            entries.add(ModBlocks.SHOWER_CABINET);
            entries.add(ModBlocks.BATHROOM_MIRROR);
            entries.add(ModBlocks.TOWEL_RACK);
            entries.add(ModBlocks.TOILET_PAPER_HOLDER);
            entries.add(ModBlocks.SOAP_DISPENSER);
            entries.add(ModBlocks.BEDSIDE_BENCH);
            entries.add(ModBlocks.SHOE_CABINET);
            entries.add(ModBlocks.ENTRY_TABLE);
            entries.add(ModBlocks.KEY_HOLDER);
            entries.add(ModBlocks.WALL_CLOCK);
            entries.add(ModBlocks.CANDLE_SET);
            entries.add(ModBlocks.BOOKS_STACK);
            entries.add(ModBlocks.PHOTO_FRAME);
            entries.add(ModBlocks.DECORATIVE_BOWL);
            entries.add(ModBlocks.LUXURY_FIREPLACE);
            entries.add(ModBlocks.WINE_CABINET);
            entries.add(ModBlocks.OTTOMAN);
            entries.add(ModBlocks.CONSOLE_TABLE);
            entries.add(ModBlocks.BAR_CART);
            entries.add(ModBlocks.ENTRY_MIRROR);
            entries.add(ModBlocks.PLANT_STAND);
            entries.add(ModBlocks.FLOOR_VASE);
            entries.add(ModBlocks.DECORATIVE_LANTERN);
            entries.add(ModBlocks.STORAGE_CUBE);
            entries.add(ModBlocks.LUXURY_HEADBOARD);
        })
        .build();

    public static void register() {
        Registry.register(Registries.ITEM_GROUP, Identifier.of(UrbanHome.MOD_ID, "urbanhome"), URBANHOME);
    }
}
